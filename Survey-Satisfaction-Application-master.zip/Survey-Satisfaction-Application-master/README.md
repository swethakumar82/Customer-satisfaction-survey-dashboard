# Survey-Quiz-Application

-------General description-----------

 - I create role based user login register platform.
 - For let users get educational quiz and comment area which saved to database with all information with encoded password.
 - Also there is results depends on users answers will calculate education was good or bad and send email to your registered email addresse. 
 - If you want, at survey page you can download whole survey list information as a excel format.
 - Each user only one time have a right to enter the quiz.
 - There is one admin panel and admin able to control whole platform but unable to touch freewill quiz results.

-------Using Guide-----------

- Register with personal information.
- Login with your new account.
- Join the quiz survey and write some message.
- Application will send notification to your email addresse.
- View the survey results and download as a excel format.
- Also you can create some personal message on dropdown button section.
- You can check all saved information from http://localhost:8080/h2-console
- After using application as a user now you can enter with admin account ||||| username : admin ||||| password : 1234 |||||
- Admin also can join everthing and also we have admin panel for to control users active passive state.

-------Used Technologies-----------

Spring boot--Java--Spring security--H2 database--Password encoder--Spring MVC--MySQL--Email Sender--Jpa--Thymeleaf--validation--TimeStamp
