package com.isakayabasi.maintermproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MainTermProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
