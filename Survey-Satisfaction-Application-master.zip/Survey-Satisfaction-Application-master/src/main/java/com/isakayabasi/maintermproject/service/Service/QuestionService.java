package com.isakayabasi.maintermproject.service.Service;


import com.isakayabasi.maintermproject.model.QuestionForm;

public interface QuestionService {

    public QuestionForm getQuestions();
}
