package com.isakayabasi.maintermproject.service.Service;


import com.isakayabasi.maintermproject.model.User;

import java.util.List;

public interface StudentService {
    List<User> getAllStudent();

}